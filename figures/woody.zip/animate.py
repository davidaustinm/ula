width = 100
height = width
margin = 5

